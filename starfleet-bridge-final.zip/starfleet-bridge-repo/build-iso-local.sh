#!/bin/bash
# Starfleet Bridge ISO Build Script for Local Files

set -euo pipefail

echo "=== STARFLEET BRIDGE ISO BUILD (Local Mode) ==="
echo "Building collective consciousness system from local files..."

# Check if we're in the right directory
if [ ! -f "configuration.nix" ] || [ ! -d "modules" ]; then
    echo "ERROR: Please run this script from the starfleet-bridge-repo directory"
    echo "Current directory: $(pwd)"
    exit 1
fi

# Create build directory
mkdir -p ./build
cd ./build

# Set up local nix-build environment
echo "Setting up local build environment..."

# Build the ISO using local configuration
echo "Building ISO with local NixOS configuration..."

# Create a minimal build configuration that works locally
cat > local-build.nix << 'EOF'
{ config, pkgs, ... }:

{
  imports = [
    # Base NixOS installation CD
    <nixpkgs/nixos/modules/installer/cd-dvd/installation-cd-minimal.nix>
    
    # Local modules
    ../modules/lcars-interface.nix
    ../modules/collective-services.nix
    ../modules/ai-services.nix
    ../modules/bridge-security.nix
  ];

  # ISO configuration
  isoImage = {
    isoName = "starfleet-bridge-local-${config.system.nixos.label}-x86_64";
    volumeID = "STARFLEET_BRIDGE_LOCAL";
    publisher = "Starfleet Bridge Local Build";
    application = "Starfleet Bridge - Collective Consciousness Interface";
    compressImage = true;
    squashfsCompression = "xz -Xbcj x86";
  };

  # System configuration
  system = {
    stateVersion = "24.05";
    nixos.label = "2025-09-26";
  };

  # Boot configuration
  boot = {
    kernelParams = [ "quiet" "splash" ];
    initrd.availableKernelModules = [ 
      "xhci_pci" "ahci" "nvme" "usb_storage" "usbhid" "sd_mod" 
    ];
    loader = {
      grub = {
        enable = true;
        version = 2;
      };
      timeout = 5;
    };
  };

  # Users and authentication
  users.users = {
    starfleet = {
      isNormalUser = true;
      description = "Starfleet Bridge Operator";
      initialPassword = "starfleet-2025";
      extraGroups = [ "networkmanager" "docker" "video" "audio" "wheel" ];
      openssh.authorizedKeys.keys = [ ];
      packages = with pkgs; [
        firefox
        thunderbird
        git
        vim
        htop
        wget
        curl
      ];
    };
  };

  # Bridge packages and services
  environment.systemPackages = with pkgs; [
    # Core utilities
    git
    vim
    htop
    tree
    wget
    curl
    unzip
    zip
    
    # LCARS interface dependencies
    python3
    python3Packages.pip
    python3Packages.psutil
    python3Packages.requests
    python3Packages.pillow
    tkinter
    cairo
    pango
    fontconfig
    dejavu_fonts
    liberation_ttf
    
    # Development tools
    rustc
    cargo
    gcc
    g++
    cmake
    pkg-config
    
    # Wayland/graphics support
    wayland
    wayland-protocols
    mesa
    libinput
    xorg.libX11
    
    # Monitoring and collective services
    prometheus
    grafana
    loki
    wireguard-tools
    networkmanager
    iptables
    
    # Security tools
    nmap
    wireshark
    nikto
    john
    hashcat
    aircrack-ng
    sqlmap
    metasploit
    hydra
    netcat-gnu
    tcpdump
    
    # AI services
    ollama
    espeak
    festival
    
    # System tools
    smartmontools
    lm_sensors
    pciutils
    usbutils
  ];

  # Services configuration
  services = {
    # Display manager
    displayManager.sddm.enable = true;
    desktopManager.plasma5.enable = true;
    
    # SSH for remote management
    openssh.enable = true;
    
    # Docker for containerized services
    docker.enable = true;
    docker.rootless.enable = true;
    
    # Prometheus monitoring
    prometheus.enable = true;
    prometheus.port = 9090;
    
    # Grafana dashboards
    grafana.enable = true;
    grafana.settings.server.http_port = 3000;
    grafana.settings.server.domain = "bridge.starfleet.local";
    
    # WireGuard for collective mesh
    wireguard.enable = true;
    wireguard.interfaces.wg0 = {
      ips = [ "10.0.0.1/24" ];
      listenPort = 51820;
      privateKeyFile = "/etc/wireguard/bridge.key";
    };
  };

  # Firewall configuration
  networking.firewall = {
    enable = true;
    allowPing = true;
    allowedTCPPorts = [ 22 80 443 3000 9090 11434 51820 ];
    allowedUDPPorts = [ 51820 ];
  };

  # Network configuration
  networking = {
    hostName = "starfleet-bridge";
    useDHCP = false;
    interfaces.eth0.useDHCP = true;
    nat = {
      enable = true;
      externalInterface = "eth0";
      internalInterfaces = [ "wg0" ];
    };
  };

  # Performance optimization
  boot.kernel.sysctl = {
    "vm.swappiness" = 10;
    "vm.dirty_ratio" = 15;
    "vm.dirty_background_ratio" = 5;
    "net.core.rmem_max" = 16777216;
    "net.core.wmem_max" = 16777216;
    "net.ipv4.ip_forward" = 1;
  };

  # Hardware support
  hardware.enableAllFirmware = true;
  boot.initrd.availableKernelModules = [ 
    "xhci_pci" "ahci" "nvme" "usb_storage" "usbhid" "sd_mod" "virtio" "virtio_pci"
  ];

  # System state version
  system.stateVersion = "24.05";
}
EOF

# Try to build the ISO
echo "Building ISO image..."
if command -v nix-build >/dev/null 2>&1; then
    nix-build '<nixpkgs/nixos>' -A config.system.build.isoImage \
      -I nixos-config=./local-build.nix \
      --option sandbox false \
      --option build-use-sandbox false
else
    echo "WARNING: nix-build not found. Trying alternative build method..."
    
    # Create a simple ISO build script that works with local files
    cat > build-simple.sh << 'EOF'
#!/bin/bash
# Simple ISO build for NixOS systems

echo "Creating simple NixOS ISO configuration..."

# Create a basic ISO configuration that works on NixOS systems
cat > iso-config.nix << 'ISOCONFIG'
{ config, pkgs, ... }:

{
  imports = [
    <nixpkgs/nixos/modules/installer/cd-dvd/installation-cd-minimal.nix>
  ];

  # Basic ISO configuration
  isoImage = {
    isoName = "starfleet-bridge-basic-x86_64";
    volumeID = "STARFLEET_BASIC";
  };

  # System configuration
  system.stateVersion = "24.05";
  
  # Users
  users.users.starfleet = {
    isNormalUser = true;
    initialPassword = "starfleet-2025";
    extraGroups = [ "networkmanager" "wheel" ];
    packages = with pkgs; [ firefox vim htop wget curl ];
  };

  # Packages
  environment.systemPackages = with pkgs; [
    python3 python3Packages.pip python3Packages.psutil python3Packages.requests
    prometheus grafana wireguard-tools networkmanager
    nmap wireshark nikto john hashcat
    ollama espeak festival
    git vim htop tree wget curl unzip
  ];

  # Services
  services = {
    openssh.enable = true;
    prometheus.enable = true;
    grafana.enable = true;
    docker.enable = true;
  };

  # Network
  networking.firewall.enable = true;
  networking.hostName = "starfleet-bridge";

  system.stateVersion = "24.05";
}
ISCONFIG

echo "Created basic ISO configuration: iso-config.nix"
echo "You can now use this with nixos-generate-config or other NixOS tools."

EOF

    chmod +x build-simple.sh
    echo "Created simple build script: build-simple.sh"
    echo "Run ./build-simple.sh to create basic ISO configuration"
fi

echo "=== BUILD PROCESS COMPLETE ==="
echo "Check the build directory for results"
echo "If nix-build succeeded, ISO will be in: ./result/iso/"
echo "If using simple build, configuration will be in: ./iso-config.nix"