#!/usr/bin/env python3
"""
LCARS Bridge Interface - Starfleet Command Console
Starfleet Operating System - Collective Consciousness Interface
For NixOS Bridge System
"""

import tkinter as tk
from tkinter import ttk, messagebox
import psutil
import subprocess
import json
import time
import threading
import requests
import os
from datetime import datetime

class LCARSBridgeInterface:
    def __init__(self):
        self.root = tk.Tk()
        self.root.title("STARFLEET BRIDGE - USS OPTIPLEX 9010")
        self.root.configure(bg='#001122')
        self.root.attributes('-fullscreen', True)
        
        # LCARS Color Palette
        self.colors = {
            'primary': '#FF9900',     # Orange
            'secondary': '#3366CC',   # Blue  
            'accent': '#FFFFFF',      # White
            'background': '#001122',  # Very dark blue
            'panel_bg': '#003366',    # Dark blue
            'warning': '#FF3300',     # Red
            'success': '#00FF66',     # Green
        }
        
        # System state
        self.collective_nodes = []
        self.system_alerts = []
        self.mission_status = "OPERATIONAL"
        self.threat_level = "GREEN"
        
        self.setup_interface()
        self.start_monitoring()
        
    def setup_interface(self):
        """Create comprehensive LCARS interface"""
        # Main container
        main_frame = tk.Frame(self.root, bg=self.colors['background'])
        main_frame.pack(fill=tk.BOTH, expand=True, padx=5, pady=5)
        
        # Header banner - LCARS style
        self.create_header_banner(main_frame)
        
        # Main content area with panels
        content_frame = tk.Frame(main_frame, bg=self.colors['background'])
        content_frame.pack(fill=tk.BOTH, expand=True, pady=10)
        
        # Left panel - Bridge Operations
        left_panel = tk.Frame(content_frame, bg=self.colors['background'])
        left_panel.pack(side=tk.LEFT, fill=tk.BOTH, expand=True, padx=(0, 5))
        
        self.create_bridge_control_panel(left_panel)
        self.create_system_monitoring_panel(left_panel)
        
        # Right panel - Collective & Tactical
        right_panel = tk.Frame(content_frame, bg=self.colors['background'])
        right_panel.pack(side=tk.RIGHT, fill=tk.BOTH, expand=True, padx=(5, 0))
        
        self.create_collective_consciousness_panel(right_panel)
        self.create_tactical_operations_panel(right_panel)
        
        # Bottom status bar
        self.create_status_bar(main_frame)
        
        # Bind keyboard shortcuts
        self.root.bind('<F11>', self.toggle_fullscreen)
        self.root.bind('<Escape>', self.show_exit_dialog)
        self.root.bind('<Control-q>', self.emergency_shutdown)
        
    def create_header_banner(self, parent):
        """LCARS-style header banner"""
        header = tk.Frame(parent, bg=self.colors['primary'], height=80)
        header.pack(fill=tk.X, pady=(0, 10))
        
        # Starfleet insignia area (left)
        insignia_frame = tk.Frame(header, bg=self.colors['primary'], width=100)
        insignia_frame.pack(side=tk.LEFT, fill=tk.Y, padx=10)
        
        tk.Label(insignia_frame, text="★", 
                bg=self.colors['primary'], fg='black',
                font=('DejaVu Sans', 24, 'bold')).pack(pady=15)
        
        # Main title (center)
        title_frame = tk.Frame(header, bg=self.colors['primary'])
        title_frame.pack(side=tk.LEFT, expand=True)
        
        tk.Label(title_frame, text="STARFLEET BRIDGE COMMAND INTERFACE", 
                bg=self.colors['primary'], fg='black',
                font=('DejaVu Sans', 20, 'bold')).pack(pady=25)
        
        # Status indicators (right)
        status_frame = tk.Frame(header, bg=self.colors['primary'])
        status_frame.pack(side=tk.RIGHT, padx=20)
        
        self.date_label = tk.Label(status_frame, 
                                 text=datetime.now().strftime("%Y-%m-%d"),
                                 bg=self.colors['primary'], fg='black',
                                 font=('DejaVu Sans', 12))
        self.date_label.pack()
        
        self.time_label = tk.Label(status_frame,
                                 text=datetime.now().strftime("%H:%M:%S"),
                                 bg=self.colors['primary'], fg='black', 
                                 font=('DejaVu Sans', 12, 'bold'))
        self.time_label.pack()
        
    def create_bridge_control_panel(self, parent):
        """Main bridge control panel"""
        panel = tk.LabelFrame(parent, text="BRIDGE OPERATIONS",
                            bg=self.colors['panel_bg'], fg=self.colors['accent'],
                            font=('DejaVu Sans', 14, 'bold'), padx=10, pady=10)
        panel.pack(fill=tk.X, pady=(0, 10))
        
        # Mission control buttons
        button_frame = tk.Frame(panel, bg=self.colors['panel_bg'])
        button_frame.pack(fill=tk.X, pady=5)
        
        mission_btn = tk.Button(button_frame, text="MISSION CONTROL",
                              command=self.open_mission_control,
                              bg=self.colors['secondary'], fg='white',
                              font=('DejaVu Sans', 12, 'bold'),
                              width=15, height=2)
        mission_btn.pack(side=tk.LEFT, padx=5)
        
        scan_btn = tk.Button(button_frame, text="COLLECTIVE SCAN",
                           command=self.scan_collective,
                           bg=self.colors['primary'], fg='black',
                           font=('DejaVu Sans', 12, 'bold'),
                           width=15, height=2)
        scan_btn.pack(side=tk.LEFT, padx=5)
        
        alert_btn = tk.Button(button_frame, text="ALERT STATUS",
                            command=self.set_alert_level,
                            bg=self.colors['warning'], fg='white',
                            font=('DejaVu Sans', 12, 'bold'),
                            width=15, height=2)
        alert_btn.pack(side=tk.LEFT, padx=5)
        
        # System information display
        info_frame = tk.Frame(panel, bg=self.colors['panel_bg'])
        info_frame.pack(fill=tk.X, pady=10)
        
        self.system_info_text = tk.Text(info_frame, height=6, width=40,
                                      bg='black', fg=self.colors['accent'],
                                      font=('DejaVu Sans', 10))
        self.system_info_text.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        
        # Scrollbar
        scrollbar = tk.Scrollbar(info_frame, command=self.system_info_text.yview)
        scrollbar.pack(side=tk.RIGHT, fill=tk.Y)
        self.system_info_text.config(yscrollcommand=scrollbar.set)
        
        # Initial system info
        self.update_system_info()
        
    def create_system_monitoring_panel(self, parent):
        """Real-time system monitoring"""
        panel = tk.LabelFrame(parent, text="SYSTEM MONITORING",
                            bg=self.colors['panel_bg'], fg=self.colors['accent'],
                            font=('DejaVu Sans', 14, 'bold'), padx=10, pady=10)
        panel.pack(fill=tk.BOTH, expand=True)
        
        # CPU usage
        cpu_frame = tk.Frame(panel, bg=self.colors['panel_bg'])
        cpu_frame.pack(fill=tk.X, pady=5)
        
        tk.Label(cpu_frame, text="CPU USAGE:",
                bg=self.colors['panel_bg'], fg=self.colors['accent'],
                font=('DejaVu Sans', 12)).pack(side=tk.LEFT)
        
        self.cpu_bar = ttk.Progressbar(cpu_frame, length=200, mode='determinate')
        self.cpu_bar.pack(side=tk.LEFT, padx=10)
        
        self.cpu_label = tk.Label(cpu_frame, text="0%",
                                bg=self.colors['panel_bg'], fg=self.colors['accent'])
        self.cpu_label.pack(side=tk.LEFT)
        
        # Memory usage
        mem_frame = tk.Frame(panel, bg=self.colors['panel_bg'])
        mem_frame.pack(fill=tk.X, pady=5)
        
        tk.Label(mem_frame, text="MEMORY:",
                bg=self.colors['panel_bg'], fg=self.colors['accent'],
                font=('DejaVu Sans', 12)).pack(side=tk.LEFT)
        
        self.mem_bar = ttk.Progressbar(mem_frame, length=200, mode='determinate')
        self.mem_bar.pack(side=tk.LEFT, padx=10)
        
        self.mem_label = tk.Label(mem_frame, text="0%",
                                bg=self.colors['panel_bg'], fg=self.colors['accent'])
        self.mem_label.pack(side=tk.LEFT)
        
        # Network status
        net_frame = tk.Frame(panel, bg=self.colors['panel_bg'])
        net_frame.pack(fill=tk.X, pady=5)
        
        tk.Label(net_frame, text="NETWORK:",
                bg=self.colors['panel_bg'], fg=self.colors['accent'],
                font=('DejaVu Sans', 12)).pack(side=tk.LEFT)
        
        self.net_status = tk.Label(net_frame, text="INITIALIZING",
                                 bg=self.colors['panel_bg'], fg=self.colors['warning'])
        self.net_status.pack(side=tk.LEFT, padx=10)
        
    def create_collective_consciousness_panel(self, parent):
        """Collective consciousness interface"""
        panel = tk.LabelFrame(parent, text="COLLECTIVE CONSCIOUSNESS",
                            bg=self.colors['panel_bg'], fg=self.colors['accent'],
                            font=('DejaVu Sans', 14, 'bold'), padx=10, pady=10)
        panel.pack(fill=tk.BOTH, expand=True, pady=(0, 10))
        
        # Collective status display
        self.collective_text = tk.Text(panel, height=10, width=35,
                                     bg='black', fg=self.colors['accent'],
                                     font=('DejaVu Sans', 10))
        self.collective_text.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        
        # Scrollbar
        scrollbar = tk.Scrollbar(panel, command=self.collective_text.yview)
        scrollbar.pack(side=tk.RIGHT, fill=tk.Y)
        self.collective_text.config(yscrollcommand=scrollbar.set)
        
        # Initial collective status
        self.update_collective_status()
        
    def create_tactical_operations_panel(self, parent):
        """Tactical operations and security"""
        panel = tk.LabelFrame(parent, text="TACTICAL OPERATIONS",
                            bg=self.colors['panel_bg'], fg=self.colors['accent'],
                            font=('DejaVu Sans', 14, 'bold'), padx=10, pady=10)
        panel.pack(fill=tk.BOTH, expand=True)
        
        # Security tools frame
        tools_frame = tk.Frame(panel, bg=self.colors['panel_bg'])
        tools_frame.pack(fill=tk.X, pady=5)
        
        # Network scan button
        netscan_btn = tk.Button(tools_frame, text="NETWORK SCAN",
                              command=self.network_scan,
                              bg=self.colors['warning'], fg='white',
                              font=('DejaVu Sans', 10, 'bold'))
        netscan_btn.pack(side=tk.LEFT, padx=2)
        
        # Port scan button
        portscan_btn = tk.Button(tools_frame, text="PORT SCAN",
                               command=self.port_scan,
                               bg=self.colors['warning'], fg='white',
                               font=('DejaVu Sans', 10, 'bold'))
        portscan_btn.pack(side=tk.LEFT, padx=2)
        
        # System info button
        sysinfo_btn = tk.Button(tools_frame, text="SYSTEM INFO",
                              command=self.system_info,
                              bg=self.colors['secondary'], fg='white',
                              font=('DejaVu Sans', 10, 'bold'))
        sysinfo_btn.pack(side=tk.LEFT, padx=2)
        
        # Tactical display
        self.tactical_display = tk.Text(panel, height=8, width=35,
                                      bg='black', fg=self.colors['accent'],
                                      font=('DejaVu Sans', 10))
        self.tactical_display.pack(fill=tk.BOTH, expand=True, pady=5)
        
        # Initial tactical info
        self.update_tactical_display()
        
    def create_status_bar(self, parent):
        """Bottom status bar"""
        status_frame = tk.Frame(parent, bg=self.colors['secondary'])
        status_frame.pack(fill=tk.X, pady=(10, 0))
        
        # Left side - system status
        self.status_text = tk.StringVar()
        self.status_text.set("BRIDGE STATUS: INITIALIZING")
        
        status_label = tk.Label(status_frame, textvariable=self.status_text,
                              bg=self.colors['secondary'], fg='white',
                              font=('DejaVu Sans', 12, 'bold'))
        status_label.pack(side=tk.LEFT, padx=10)
        
        # Right side - indicators
        indicator_frame = tk.Frame(status_frame, bg=self.colors['secondary'])
        indicator_frame.pack(side=tk.RIGHT, padx=10)
        
        # Time indicator
        self.time_indicator = tk.Label(indicator_frame,
                                     text=datetime.now().strftime("%H:%M:%S"),
                                     bg=self.colors['secondary'], fg='white',
                                     font=('DejaVu Sans', 12))
        self.time_indicator.pack(side=tk.LEFT, padx=5)
        
        # Threat indicator
        self.threat_indicator = tk.Label(indicator_frame,
                                       text=f"THREAT: {self.threat_level}",
                                       bg=self.colors['primary'], fg='black',
                                       font=('DejaVu Sans', 10, 'bold'))
        self.threat_indicator.pack(side=tk.LEFT, padx=5)
        
    def update_system_info(self):
        """Update system information display"""
        try:
            # Get real system stats
            cpu_percent = psutil.cpu_percent(interval=1)
            memory = psutil.virtual_memory()
            disk = psutil.disk_usage('/')
            boot_time = datetime.fromtimestamp(psutil.boot_time())
            
            # Get hostname
            hostname = subprocess.check_output(['hostname']).decode().strip()
            
            info_text = f"""
=== BRIDGE SYSTEM STATUS ===
Hostname: {hostname}
CPU Usage: {cpu_percent:.1f}%
Memory: {memory.used // (1024**3)}GB / {memory.total // (1024**3)}GB
Disk Usage: {disk.used // (1024**3)}GB / {disk.total // (1024**3)}GB
Boot Time: {boot_time.strftime('%Y-%m-%d %H:%M:%S')}
Current Time: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}
Mission Status: {self.mission_status}
Collective Nodes: {len(self.collective_nodes)}

=== COLLECTIVE INTEGRATION ===
WireGuard Status: {'ACTIVE' if self.check_wireguard() else 'INACTIVE'}
Prometheus: {'ONLINE' if self.check_prometheus() else 'OFFLINE'}
Grafana: {'ONLINE' if self.check_grafana() else 'OFFLINE'}
            """
            
            self.system_info_text.delete(1.0, tk.END)
            self.system_info_text.insert(tk.END, info_text)
            
        except Exception as e:
            self.system_info_text.insert(tk.END, f"Error getting system info: {e}\n")
            
    def update_collective_status(self):
        """Update collective consciousness status"""
        status_text = f"""
=== COLLECTIVE CONSCIOUSNESS ===
Bridge Node: OPERATIONAL
Node ID: BRIDGE-9010
IP Address: 10.0.0.1
WireGuard: {'ACTIVE' if self.check_wireguard() else 'INACTIVE'}

CONNECTED NODES:
{self.format_collective_nodes()}

MESH NETWORK STATUS:
Routing: ENABLED
Encryption: ACTIVE
Protocol: WireGuard

AI SERVICES:
Status: STANDBY
Models: Ready for deployment
Inference: Available

Last Update: {datetime.now().strftime('%H:%M:%S')}
        """
        
        self.collective_text.delete(1.0, tk.END)
        self.collective_text.insert(tk.END, status_text)
        
    def update_tactical_display(self):
        """Update tactical operations display"""
        tactical_text = f"""
=== TACTICAL OPERATIONS ===
Threat Level: {self.threat_level}
Shields: {'RAISED' if self.threat_level == 'RED' else 'STANDBY'}
Weapons: {'HOT' if self.threat_level == 'RED' else 'SAFE'}

NETWORK SECURITY:
Firewall: ACTIVE
Intrusion Detection: MONITORING
Access Control: RESTRICTED

RECENT ACTIVITY:
{datetime.now().strftime('%H:%M:%S')} - System scan completed
{datetime.now().strftime('%H:%M:%S')} - Network monitoring active
{datetime.now().strftime('%H:%M:%S')} - Collective mesh operational

Ready for tactical operations.
        """
        
        self.tactical_display.delete(1.0, tk.END)
        self.tactical_display.insert(tk.END, tactical_text)
        
    def update_monitoring(self):
        """Update real-time monitoring data"""
        try:
            # CPU usage
            cpu_percent = psutil.cpu_percent(interval=None)
            self.cpu_bar['value'] = cpu_percent
            self.cpu_label.config(text=f"{cpu_percent:.1f}%")
            
            # Memory usage
            memory = psutil.virtual_memory()
            self.mem_bar['value'] = memory.percent
            self.mem_label.config(text=f"{memory.percent:.1f}%")
            
            # Network status
            if self.check_wireguard():
                self.net_status.config(text="WIREGUARD ACTIVE", fg=self.colors['success'])
            else:
                self.net_status.config(text="WIREGUARD INACTIVE", fg=self.colors['warning'])
                
            # Update status
            if len(self.collective_nodes) > 0:
                self.system_status = "COLLECTIVE ACTIVE"
                self.threat_level = "GREEN"
            else:
                self.system_status = "BRIDGE ONLY"
                self.threat_level = "YELLOW"
                
            self.status_text.set(f"BRIDGE STATUS: {self.system_status}")
            self.threat_indicator.config(text=f"THREAT: {self.threat_level}")
            
        except Exception as e:
            print(f"Monitoring update error: {e}")
            
    def update_time(self):
        """Update clock display"""
        self.time_indicator.config(text=datetime.now().strftime("%H:%M:%S"))
        self.root.after(1000, self.update_time)
        
    # Event handlers
    def toggle_fullscreen(self, event=None):
        """Toggle fullscreen mode"""
        self.root.attributes('-fullscreen', not self.root.attributes('-fullscreen'))
        
    def show_exit_dialog(self, event=None):
        """Show exit confirmation"""
        if messagebox.askyesno("Bridge Shutdown", "Deactivate Starfleet Bridge?"):
            self.root.destroy()
            
    def emergency_shutdown(self, event=None):
        """Emergency shutdown procedure"""
        if messagebox.askyesno("EMERGENCY SHUTDOWN", "INITIATE EMERGENCY SHUTDOWN?"):
            self.system_status = "EMERGENCY SHUTDOWN"
            self.status_text.set("BRIDGE STATUS: EMERGENCY SHUTDOWN")
            # Add emergency procedures here
            self.root.after(3000, self.root.destroy)
            
    def open_mission_control(self):
        """Open mission control interface"""
        messagebox.showinfo("Mission Control", "Mission Control interface coming soon!")
        
    def scan_collective(self):
        """Scan for collective nodes"""
        self.collective_text.insert(tk.END, f"\n[{datetime.now().strftime('%H:%M:%S')}] Scanning for collective nodes...\n")
        
        # Simulate finding nodes
        import random
        if random.random() > 0.8:
            node_name = f"DRONE-{random.randint(1,99):02d}"
            self.collective_nodes.append(node_name)
            self.collective_text.insert(tk.END, f"✓ Node detected: {node_name} (10.0.0.{len(self.collective_nodes) + 1})\n")
        else:
            self.collective_text.insert(tk.END, "No new nodes detected\n")
            
        self.collective_text.see(tk.END)
        self.update_collective_status()
        
    def set_alert_level(self):
        """Set bridge alert level"""
        levels = ["GREEN", "YELLOW", "RED"]
        current = levels.index(self.threat_level)
        self.threat_level = levels[(current + 1) % len(levels)]
        self.update_tactical_display()
        
    def network_scan(self):
        """Perform network scan"""
        self.tactical_display.insert(tk.END, f"\n[{datetime.now().strftime('%H:%M:%S')}] Network scan initiated...\n")
        try:
            # Simple network discovery
            result = subprocess.run(['ip', 'route'], capture_output=True, text=True)
            self.tactical_display.insert(tk.END, "Network routes discovered:\n")
            self.tactical_display.insert(tk.END, result.stdout)
        except Exception as e:
            self.tactical_display.insert(tk.END, f"Scan error: {e}\n")
        self.tactical_display.see(tk.END)
        
    def port_scan(self):
        """Basic port scan"""
        self.tactical_display.insert(tk.END, f"\n[{datetime.now().strftime('%H:%M:%S')}] Port scan on localhost...\n")
        try:
            # Check common ports
            ports = [22, 80, 443, 3000, 9090]
            for port in ports:
                result = subprocess.run(['nc', '-z', '-v', 'localhost', str(port)], 
                                      capture_output=True, text=True)
                if result.returncode == 0:
                    self.tactical_display.insert(tk.END, f"Port {port}: OPEN\n")
                else:
                    self.tactical_display.insert(tk.END, f"Port {port}: closed\n")
        except Exception as e:
            self.tactical_display.insert(tk.END, f"Port scan error: {e}\n")
        self.tactical_display.see(tk.END)
        
    def system_info(self):
        """Display detailed system information"""
        self.tactical_display.insert(tk.END, f"\n[{datetime.now().strftime('%H:%M:%S')}] Detailed system information:\n")
        try:
            # System info
            uname = subprocess.check_output(['uname', '-a']).decode()
            self.tactical_display.insert(tk.END, f"System: {uname}\n")
            
            # CPU info
            with open('/proc/cpuinfo', 'r') as f:
                for line in f:
                    if 'model name' in line:
                        self.tactical_display.insert(tk.END, f"CPU: {line.split(':')[1].strip()}\n")
                        break
                        
            # Memory info
            mem = psutil.virtual_memory()
            self.tactical_display.insert(tk.END, f"Memory: {mem.total // (1024**3)} GB total\n")
            
        except Exception as e:
            self.tactical_display.insert(tk.END, f"System info error: {e}\n")
        self.tactical_display.see(tk.END)
        
    # Utility methods
    def check_wireguard(self):
        """Check if WireGuard is active"""
        try:
            result = subprocess.run(['wg', 'show'], capture_output=True, text=True)
            return result.returncode == 0 and len(result.stdout.strip()) > 0
        except:
            return False
            
    def check_prometheus(self):
        """Check if Prometheus is running"""
        try:
            response = requests.get('http://localhost:9090/-/healthy', timeout=2)
            return response.status_code == 200
        except:
            return False
            
    def check_grafana(self):
        """Check if Grafana is running"""
        try:
            response = requests.get('http://localhost:3000/api/health', timeout=2)
            return response.status_code == 200
        except:
            return False
            
    def format_collective_nodes(self):
        """Format collective nodes list"""
        if not self.collective_nodes:
            return "No nodes connected"
        return '\n'.join([f"• {node}" for node in self.collective_nodes])
            
    def run(self):
        """Start the Bridge interface"""
        print("=== STARFLEET BRIDGE ACTIVATED ===")
        print("LCARS Interface v1.0.0")
        print("Collective Node: BRIDGE-9010")
        print("=================================")
        self.root.mainloop()

if __name__ == "__main__":
    bridge = LCARSBridgeInterface()
    bridge.run()