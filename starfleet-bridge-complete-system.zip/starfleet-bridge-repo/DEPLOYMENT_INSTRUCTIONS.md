# Starfleet Bridge Deployment Instructions
## For Complete Beginners

### Overview
This guide will help you deploy the Starfleet Bridge Operating System on your hardware. The system transforms your computer into a Starfleet command center with collective consciousness capabilities.

### Prerequisites
- A computer (preferably Dell OptiPlex 9010) with at least 4GB RAM
- USB drive (8GB or larger)
- Internet connection
- Basic command line knowledge

### Step 1: Download the System Package
1. Download the file `starfleet-bridge-os.zip` from the sandbox environment
2. Save it to your computer (Downloads folder is fine)

### Step 2: Upload to GitHub
1. Go to your repository: https://github.com/chrisk-2/starfleet-bridge-os
2. Click the "Add file" button (green button on right)
3. Select "Upload files"
4. Drag and drop the `starfleet-bridge-os.zip` file
5. Add a commit message like "Upload Starfleet Bridge OS package"
6. Click "Commit changes"

### Step 3: Clone Repository to Your Local Machine
Open a terminal and run:
```bash
git clone https://github.com/chrisk-2/starfleet-bridge-os.git
cd starfleet-bridge-os
```

### Step 4: Extract the System Files
```bash
unzip starfleet-bridge-os.zip
```

If you don't have unzip installed:
```bash
# Ubuntu/Debian
sudo apt install unzip

# Or on macOS
brew install unzip
```

### Step 5: Install Nix Package Manager
The ISO build process requires Nix:

**For Linux (Ubuntu/Debian/Fedora):**
```bash
# Ubuntu/Debian
sudo apt update
sudo apt install curl
curl -L https://nixos.org/nix/install | sh

# Fedora
sudo dnf install nix
```

**For macOS:**
```bash
curl -L https://nixos.org/nix/install | sh
```

**For Windows:**
Use WSL (Windows Subsystem for Linux) with Ubuntu, then follow Linux instructions.

After installation, restart your terminal or run:
```bash
source ~/.nix-profile/etc/profile.d/nix.sh
```

### Step 6: Build the Starfleet Bridge ISO
```bash
cd starfleet-bridge-repo
chmod +x build-iso.sh
sudo ./build-iso.sh
```

This will:
1. Build the complete NixOS system
2. Create a bootable ISO image
3. Generate checksum files for verification

The ISO will be created in: `./build/result/iso/starfleet-bridge-*.iso`

### Step 7: Create Installation Media
1. Insert your USB drive into your computer
2. Find your USB device name:
   ```bash
   lsblk
   ```
   Look for your USB drive (usually something like `/dev/sdb`)

3. Burn the ISO to your USB drive:
   ```bash
   sudo dd if=./build/result/iso/starfleet-bridge-*.iso of=/dev/sdX bs=4M status=progress oflag=sync
   ```
   Replace `/dev/sdX` with your actual USB device name

### Step 8: Boot Your OptiPlex 9010
1. Insert the USB drive into your OptiPlex 9010
2. Power on the computer
3. Press F12 during boot to access the boot menu
4. Select your USB drive from the list
5. The system will boot automatically

### Step 9: Use the Starfleet Bridge
1. The LCARS interface will start automatically
2. Login with:
   - Username: `starfleet`
   - Password: `starfleet-2025`
3. Explore the panels:
   - Bridge Operations (top-left)
   - System Monitoring (bottom-left)
   - Collective Consciousness (top-right)
   - Tactical Operations (bottom-right)

### Step 10: Expand Your Collective (Advanced)
To add more computers to your collective:

1. Burn the same ISO to additional USB drives
2. Boot other computers with the ISO
3. Configure WireGuard networking between nodes:
   ```bash
   # On the Bridge node, get the public key
   sudo cat /etc/wireguard/bridge.pub
   
   # On drone nodes, configure peer connection to Bridge
   sudo nano /etc/wireguard/wg0.conf
   ```

4. Restart WireGuard on all nodes:
   ```bash
   sudo systemctl restart wg-quick@wg0
   ```

### Troubleshooting Common Issues

#### Issue: "sudo: command not found"
Solution: Install sudo package:
```bash
# Ubuntu/Debian
su -c "apt update && apt install sudo"
```

#### Issue: ISO build fails
Solution: 
1. Check that Nix is properly installed
2. Ensure you have at least 10GB free disk space
3. Try building without sudo first:
   ```bash
   ./build-iso.sh
   ```

#### Issue: USB drive not found
Solution:
1. Check device name with `lsblk`
2. Make sure USB is properly inserted
3. Unplug and replug USB drive if needed

#### Issue: LCARS interface doesn't start
Solution:
1. Check that display manager is running:
   ```bash
   systemctl status display-manager
   ```
2. Manually start LCARS interface:
   ```bash
   sudo systemctl start lcars-bridge
   ```

### System Features
Once deployed, your Starfleet Bridge will include:
- Authentic LCARS interface with orange/blue Starfleet theme
- WireGuard encrypted mesh networking for collective consciousness
- Prometheus system monitoring with Grafana dashboards
- Ollama AI services with natural language processing
- Security tools including Nmap, Metasploit, and Nikto
- Automatic fullscreen startup with keyboard shortcuts
- Multiple interface modes (Starfleet, Section 31, Borg, etc.)

### Next Steps
1. Explore the documentation in `/docs/` directory
2. Customize the LCARS interface colors and panels
3. Add AI models for enhanced intelligence capabilities
4. Connect additional computers to expand your collective
5. Configure security scanning and penetration testing tools

Enjoy your new Starfleet Bridge Operating System! Live long and prosper! 🖖