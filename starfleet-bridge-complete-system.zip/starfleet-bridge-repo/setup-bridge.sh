#!/bin/bash
# Starfleet Bridge Setup Script for NixOS
# For your OptiPlex 9010 system

set -euo pipefail

echo "=== STARFLEET BRIDGE SETUP ==="
echo "Configuring collective consciousness system on NixOS..."
echo "======================================"

# Check if we're on NixOS
if [ ! -f "/etc/NIXOS" ]; then
    echo "ERROR: This script is designed for NixOS systems only"
    exit 1
fi

# Create Bridge directory structure
echo "Creating Bridge directory structure..."
sudo mkdir -p /opt/starfleet-bridge
sudo mkdir -p /etc/starfleet
sudo mkdir -p /var/lib/collective

# Set up user permissions
echo "Setting up user permissions..."
sudo chown -R starfleet:users /opt/starfleet-bridge
sudo chown -R starfleet:users /var/lib/collective
sudo chmod 755 /etc/starfleet

# Copy LCARS interface
echo "Installing LCARS interface..."
sudo cp lcars-interface.py /opt/starfleet-bridge/
sudo chmod +x /opt/starfleet-bridge/lcars-interface.py
sudo chown starfleet:users /opt/starfleet-bridge/lcars-interface.py

# Create systemd service for LCARS interface
echo "Creating systemd service..."
sudo tee /etc/systemd/system/lcars-bridge.service > /dev/null << 'EOF'
[Unit]
Description=LCARS Bridge Interface - Starfleet Command Console
After=graphical.target
Wants=graphical.target

[Service]
Type=simple
User=starfleet
WorkingDirectory=/opt/starfleet-bridge
ExecStart=/usr/bin/python3 /opt/starfleet-bridge/lcars-interface.py
Restart=always
RestartSec=5
Environment="DISPLAY=:0"
Environment="HOME=/home/starfleet"

[Install]
WantedBy=graphical.target
EOF

# Create WireGuard configuration
echo "Setting up WireGuard for collective networking..."
sudo mkdir -p /etc/wireguard
sudo chmod 700 /etc/wireguard

# Generate WireGuard keys if they don't exist
if [ ! -f /etc/wireguard/bridge.key ]; then
    echo "Generating WireGuard keys..."
    wg genkey | sudo tee /etc/wireguard/bridge.key
    wg pubkey | sudo tee /etc/wireguard/bridge.pub
    sudo chmod 600 /etc/wireguard/bridge.key
fi

sudo tee /etc/wireguard/wg0.conf > /dev/null << 'EOF'
[Interface]
Address = 10.0.0.1/24
ListenPort = 51820
PrivateKey = YOUR_PRIVATE_KEY_HERE

[Peer]
PublicKey = DRONE_NODE_PUBLIC_KEY_HERE
AllowedIPs = 10.0.0.0/24
PersistentKeepalive = 25
EOF

# Configure Prometheus
echo "Setting up Prometheus monitoring..."
sudo tee /etc/prometheus/prometheus.yml > /dev/null << 'EOF'
global:
  scrape_interval: 15s
  evaluation_interval: 15s

scrape_configs:
  - job_name: 'bridge'
    static_configs:
      - targets: ['localhost:9100']
        labels:
          node: 'bridge'
          type: 'flagship'

  - job_name: 'collective-nodes'
    static_configs:
      - targets: ['10.0.0.2:9100', '10.0.0.3:9100', '10.0.0.4:9100']
        labels:
          type: 'drone'
EOF

# Configure Grafana
echo "Setting up Grafana dashboards..."
sudo tee /etc/grafana/grafana.ini > /dev/null << 'EOF'
[server]
http_port = 3000
domain = bridge.starfleet.local

[security]
admin_password = starfleet-2025
secret_key = starfleet-bridge-secret-2025

[users]
allow_sign_up = false
auto_assign_org = true
auto_assign_org_role = "Viewer"
EOF

# Create systemd services for monitoring
echo "Creating monitoring services..."
sudo tee /etc/systemd/system/prometheus.service > /dev/null << 'EOF'
[Unit]
Description=Prometheus monitoring system
After=network.target

[Service]
Type=simple
User=prometheus
ExecStart=/usr/bin/prometheus --config.file=/etc/prometheus/prometheus.yml --web.listen-address=0.0.0.0:9090
Restart=always
RestartSec=5

[Install]
WantedBy=multi-user.target
EOF

sudo tee /etc/systemd/system/grafana.service > /dev/null << 'EOF'
[Unit]
Description=Grafana dashboards
After=network.target prometheus.service

[Service]
Type=simple
User=grafana
ExecStart=/usr/bin/grafana-server --config=/etc/grafana/grafana.ini
Restart=always
RestartSec=5

[Install]
WantedBy=multi-user.target
EOF

# Create systemd service for WireGuard
sudo tee /etc/systemd/system/wg-quick@wg0.service > /dev/null << 'EOF'
[Unit]
Description=WireGuard via wg-quick(8) for wg0
After=network-online.target
Wants=network-online.target

[Service]
Type=oneshot
RemainAfterExit=yes
ExecStart=/usr/bin/wg-quick up wg0
ExecStop=/usr/bin/wg-quick down wg0

[Install]
WantedBy=multi-user.target
EOF

# Create Bridge activation script
echo "Creating Bridge activation script..."
sudo tee /opt/starfleet-bridge/activate-bridge.sh > /dev/null << 'EOF'
#!/bin/bash
echo "=== STARFLEET BRIDGE ACTIVATION ==="
echo "Initializing collective consciousness system..."

# Start monitoring services
sudo systemctl start prometheus
sudo systemctl start grafana-server
sudo systemctl start wg-quick@wg0

# Start LCARS interface
sudo systemctl start lcars-bridge

echo "Bridge systems activated!"
echo "==================================="
EOF

sudo chmod +x /opt/starfleet-bridge/activate-bridge.sh

# Create systemd service for Bridge activation
sudo tee /etc/systemd/system/starfleet-bridge-activation.service > /dev/null << 'EOF'
[Unit]
Description=Starfleet Bridge System Activation
After=graphical.target
Wants=graphical.target

[Service]
Type=oneshot
ExecStart=/opt/starfleet-bridge/activate-bridge.sh
User=root
RemainAfterExit=yes

[Install]
WantedBy=graphical.target
EOF

# Create monitoring service for collective
sudo tee /etc/systemd/system/collective-manager.service > /dev/null << 'EOF'
[Unit]
Description=Starfleet Collective Manager
After=network.target docker.service

[Service]
Type=simple
User=collective
WorkingDirectory=/var/lib/collective
ExecStart=/bin/bash -c "echo 'Collective manager started' && sleep infinity"
Restart=always
RestartSec=10

[Install]
WantedBy=multi-user.target
EOF

# Create directories and set permissions
echo "Setting up directories and permissions..."
sudo mkdir -p /var/lib/prometheus
sudo mkdir -p /var/lib/grafana
sudo mkdir -p /var/log/prometheus
sudo mkdir -p /var/log/grafana

sudo useradd -r -s /bin/false prometheus || true
sudo useradd -r -s /bin/false grafana || true
sudo useradd -r -s /bin/false collective || true

sudo chown -R prometheus:prometheus /var/lib/prometheus /var/log/prometheus
sudo chown -R grafana:grafana /var/lib/grafana /var/log/grafana
sudo chown -R collective:collective /var/lib/collective

# Reload systemd and enable services
echo "Enabling services..."
sudo systemctl daemon-reload
sudo systemctl enable prometheus
sudo systemctl enable grafana
sudo systemctl enable wg-quick@wg0
sudo systemctl enable lcars-bridge
sudo systemctl enable starfleet-bridge-activation
sudo systemctl enable collective-manager

# Create LCARS interface startup script
echo "Creating LCARS interface startup script..."
sudo tee /opt/starfleet-bridge/start-lcars.sh > /dev/null << 'EOF'
#!/bin/bash
echo "Starting LCARS Bridge Interface..."
cd /opt/starfleet-bridge
python3 lcars-interface.py &
EOF

sudo chmod +x /opt/starfleet-bridge/start-lcars.sh
sudo chown starfleet:users /opt/starfleet-bridge/start-lcars.sh

# Create Bridge status script
sudo tee /opt/starfleet-bridge/status.sh > /dev/null << 'EOF'
#!/bin/bash
echo "=== STARFLEET BRIDGE STATUS ==="
echo "Date: $(date)"
echo "Hostname: $(hostname)"
echo "Uptime: $(uptime)"
echo ""
echo "=== SERVICE STATUS ==="
systemctl status prometheus grafana-server wg-quick@wg0 lcars-bridge --no-pager -l
echo ""
echo "=== WIREGUARD STATUS ==="
sudo wg show
echo ""
echo "=== NETWORK STATUS ==="
ip addr show wg0
echo ""
echo "=== COLLECTIVE STATUS ==="
echo "Collective nodes: $(sudo wg show | grep peer | wc -l)"
echo "==================================="
EOF

sudo chmod +x /opt/starfleet-bridge/status.sh

echo "=== BRIDGE SETUP COMPLETE ==="
echo "Your Starfleet Bridge system is configured!"
echo ""
echo "Next steps:"
echo "1. Apply NixOS configuration: sudo nixos-rebuild switch"
echo "2. Start services: sudo systemctl start prometheus grafana-server wg-quick@wg0"
echo "3. Start LCARS interface: sudo systemctl start lcars-bridge"
echo "4. Or use activation script: sudo /opt/starfleet-bridge/activate-bridge.sh"
echo ""
echo "Access points:"
echo "  - LCARS Interface: Desktop application"
echo "  - Grafana: http://localhost:3000 (admin/starfleet-2025)"
echo "  - Prometheus: http://localhost:9090"
echo "==================================="