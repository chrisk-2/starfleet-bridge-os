# Starfleet Bridge NixOS Deployment
## For Your OptiPlex 9010 System

### Quick Start - Deploy in 5 Steps

#### Step 1: Clone Your Repository
```bash
cd ~/
git clone https://github.com/chrisk-2/starfleet-bridge-os.git
cd starfleet-bridge-os
```

#### Step 2: Set Up Bridge Configuration
```bash
# Copy NixOS configuration to your system
sudo cp nixos-configuration.nix /etc/nixos/configuration.nix

# Apply the configuration
sudo nixos-rebuild switch
```

#### Step 3: Install Bridge System
```bash
# Run the setup script
sudo bash setup-bridge.sh
```

#### Step 4: Start Services
```bash
# Start all Bridge services
sudo systemctl start prometheus grafana-server wg-quick@wg0 lcars-bridge

# Or use the activation script
sudo /opt/starfleet-bridge/activate-bridge.sh
```

#### Step 5: Access Your Bridge
- **LCARS Interface**: Will start automatically after login
- **Grafana Dashboard**: http://localhost:3000 (admin/starfleet-2025)
- **Prometheus**: http://localhost:9090
- **Check Status**: `sudo /opt/starfleet-bridge/status.sh`

### What You'll Get

✅ **Complete LCARS Interface**: Orange/blue Starfleet theme with all panels
✅ **Collective Networking**: WireGuard mesh ready for drone connections  
✅ **AI Services**: Ollama LLM integration for intelligent operations
✅ **Security Tools**: Nmap, Metasploit, Nikto for tactical operations
✅ **Monitoring**: Prometheus metrics with Grafana dashboards
✅ **Automatic Startup**: LCARS interface starts on boot

### System Features

#### LCARS Control Panels
- **Bridge Operations**: Mission control and system management
- **System Monitoring**: Real-time CPU, memory, and network metrics
- **Collective Consciousness**: Node status and mesh network info
- **Tactical Operations**: Security scanning and threat management

#### Collective Networking
- **WireGuard Mesh**: Encrypted tunnels between all nodes
- **IP Range**: 10.0.0.0/24 for collective communication
- **Auto-Discovery**: Automatic node detection and connection
- **Security**: End-to-end encryption with key authentication

#### AI Services
- **Local LLM**: Ollama with multiple models (llama3, mistral, phi3)
- **Voice Commands**: Speech recognition and synthesis
- **Natural Language**: Command processing and interpretation
- **Distributed Processing**: AI tasks across collective nodes

#### Security Operations
- **Network Scanning**: Nmap for topology discovery
- **Vulnerability Assessment**: Nikto for web security testing
- **Penetration Testing**: Metasploit framework integration
- **Real-time Monitoring**: Continuous threat detection

### Configuration Options

#### WireGuard Setup
Generate keys for collective expansion:
```bash
# Generate Bridge keys
wg genkey | sudo tee /etc/wireguard/bridge.key
wg pubkey | sudo tee /etc/wireguard/bridge.pub

# Add drone nodes to /etc/wireguard/wg0.conf
sudo nano /etc/wireguard/wg0.conf
```

#### AI Model Management
```bash
# List available models
ollama list

# Pull new models
ollama pull llama3
ollama pull mistral

# Set active model
ollama run llama3
```

#### Interface Customization
```bash
# Change theme colors
sudo nano /opt/starfleet-bridge/lcars-interface.py

# Restart interface
sudo systemctl restart lcars-bridge
```

### Troubleshooting

#### LCARS Interface Not Starting
```bash
# Check service status
sudo systemctl status lcars-bridge

# Check logs
sudo journalctl -u lcars-bridge -f

# Manual start
python3 /opt/starfleet-bridge/lcars-interface.py
```

#### WireGuard Connection Issues
```bash
# Check WireGuard status
sudo wg show

# Verify configuration
sudo cat /etc/wireguard/wg0.conf

# Restart WireGuard
sudo systemctl restart wg-quick@wg0
```

#### Service Problems
```bash
# Check all services
sudo /opt/starfleet-bridge/status.sh

# Restart all services
sudo systemctl restart prometheus grafana-server wg-quick@wg0 lcars-bridge
```

#### NixOS Configuration Issues
```bash
# Rebuild configuration
sudo nixos-rebuild switch

# Check for errors
sudo nixos-rebuild switch --show-trace

# Rollback if needed
sudo nixos-rebuild --rollback
```

### Expanding Your Collective

#### Add Drone Nodes
1. Install NixOS on additional computers
2. Copy configuration and set unique IP (10.0.0.2, 10.0.0.3, etc.)
3. Exchange WireGuard keys
4. Add peer configuration to Bridge

#### Specialized Nodes
- **Storage Node**: Configure for distributed storage
- **AI Node**: Dedicated to model inference
- **Security Node**: Focused on scanning and monitoring
- **Probe Node**: Lightweight for edge deployment

### Next Steps
1. **Test Basic Functionality**: Verify all services are running
2. **Connect First Drone**: Add your second computer to the collective
3. **Deploy AI Models**: Set up distributed intelligence
4. **Configure Security**: Implement scanning and monitoring
5. **Scale Up**: Add more nodes for larger collective

Your Starfleet Bridge is now ready to coordinate a fleet of computers as a unified collective consciousness with authentic LCARS interface!

Live long and prosper! 🖖