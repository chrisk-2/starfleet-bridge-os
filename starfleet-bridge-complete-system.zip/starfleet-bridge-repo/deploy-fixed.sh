#!/bin/bash
# Starfleet Bridge Deployment Script - Fixed Version
# For NixOS OptiPlex 9010

set -euo pipefail

echo "=== STARFLEET BRIDGE DEPLOYMENT (Fixed Version) ==="
echo "Deploying collective consciousness system on NixOS..."
echo "======================================"

# Check if we're on NixOS
if [ ! -f "/etc/NIXOS" ]; then
    echo "ERROR: This script is designed for NixOS systems only"
    exit 1
fi

echo "Step 1: Applying fixed NixOS configuration..."
sudo cp nixos-configuration-fixed.nix /etc/nixos/configuration.nix

echo "Step 2: Building new system configuration..."
sudo nixos-rebuild switch

echo "Step 3: Setting up Bridge directory structure..."
sudo mkdir -p /opt/starfleet-bridge
sudo mkdir -p /etc/starfleet
sudo mkdir -p /var/lib/collective

# Set up user permissions
sudo chown -R starfleet:users /opt/starfleet-bridge
sudo chown -R starfleet:users /var/lib/collective
sudo chmod 755 /etc/starfleet

echo "Step 4: Installing LCARS interface..."
sudo cp lcars-interface.py /opt/starfleet-bridge/
sudo chmod +x /opt/starfleet-bridge/lcars-interface.py
sudo chown starfleet:users /opt/starfleet-bridge/lcars-interface.py

echo "Step 5: Setting up WireGuard for collective networking..."
sudo mkdir -p /etc/wireguard
sudo chmod 700 /etc/wireguard

# Generate WireGuard keys if they don't exist
if [ ! -f /etc/wireguard/bridge.key ]; then
    echo "Generating WireGuard keys..."
    wg genkey | sudo tee /etc/wireguard/bridge.key
    wg pubkey | sudo tee /etc/wireguard/bridge.pub
    sudo chmod 600 /etc/wireguard/bridge.key
fi

echo "Step 6: Creating systemd service for LCARS interface..."
sudo tee /etc/systemd/system/lcars-bridge.service > /dev/null << 'EOF'
[Unit]
Description=LCARS Bridge Interface - Starfleet Command Console
After=graphical.target
Wants=graphical.target

[Service]
Type=simple
User=starfleet
WorkingDirectory=/opt/starfleet-bridge
ExecStart=/usr/bin/python3 /opt/starfleet-bridge/lcars-interface.py
Restart=always
RestartSec=5
Environment="DISPLAY=:0"
Environment="HOME=/home/starfleet"

[Install]
WantedBy=graphical.target
EOF

echo "Step 7: Creating Bridge activation script..."
sudo tee /opt/starfleet-bridge/activate-bridge.sh > /dev/null << 'EOF'
#!/bin/bash
echo "=== STARFLEET BRIDGE ACTIVATION ==="
echo "Initializing collective consciousness system..."

# Start monitoring services
sudo systemctl start prometheus
sudo systemctl start grafana-server
sudo systemctl start wg-quick@wg0

# Start LCARS interface
sudo systemctl start lcars-bridge

echo "Bridge systems activated!"
echo "==================================="
EOF

sudo chmod +x /opt/starfleet-bridge/activate-bridge.sh

echo "Step 8: Creating status check script..."
sudo tee /opt/starfleet-bridge/status.sh > /dev/null << 'EOF'
#!/bin/bash
echo "=== STARFLEET BRIDGE STATUS ==="
echo "Date: $(date)"
echo "Hostname: $(hostname)"
echo "Uptime: $(uptime)"
echo ""
echo "=== SERVICE STATUS ==="
systemctl status prometheus grafana-server lcars-bridge --no-pager -l
echo ""
echo "=== SYSTEM INFO ==="
echo "CPU: $(nproc) cores"
echo "Memory: $(free -h | grep Mem | awk '{print $2}') total"
echo "Disk: $(df -h / | tail -1 | awk '{print $4}') available"
echo ""
echo "=== LCARS INTERFACE ==="
if systemctl is-active --quiet lcars-bridge; then
    echo "LCARS Interface: ACTIVE"
else
    echo "LCARS Interface: INACTIVE"
fi
echo "==================================="
EOF

sudo chmod +x /opt/starfleet-bridge/status.sh

echo "Step 9: Enabling and starting services..."
sudo systemctl daemon-reload
sudo systemctl enable lcars-bridge

echo "Step 10: Starting Bridge services..."
sudo systemctl start prometheus
sudo systemctl start grafana-server
sudo systemctl start lcars-bridge

echo "=== BRIDGE DEPLOYMENT COMPLETE ==="
echo "Your Starfleet Bridge system is configured and running!"
echo ""
echo "Access points:"
echo "  - LCARS Interface: Check your desktop after login"
echo "  - Grafana: http://localhost:3000 (admin/starfleet-2025)"
echo "  - Prometheus: http://localhost:9090"
echo "  - Status: sudo /opt/starfleet-bridge/status.sh"
echo ""
echo "To activate full Bridge: sudo /opt/starfleet-bridge/activate-bridge.sh"
echo "======================================="