#!/bin/bash
# Starfleet Bridge ISO Build Script

set -euo pipefail

echo "=== STARFLEET BRIDGE ISO BUILD ==="
echo "Creating bootable collective consciousness system..."

# Create build directory
mkdir -p ./build
cd ./build

# Build the ISO using nix-build
echo "Building ISO image..."
nix-build '<nixpkgs/nixos>' -A config.system.build.isoImage \
  -I nixos-config=../default.nix \
  --option sandbox false \
  --option build-use-sandbox false

# Check if build was successful
if [ -e result/iso/*.iso ]; then
  ISO_FILE=$(find result/iso -name "*.iso" | head -n1)
  ISO_NAME=$(basename "$ISO_FILE")
  
  echo "ISO build successful!"
  echo "Generated file: $ISO_FILE"
  echo "ISO name: $ISO_NAME"
  
  # Create checksums
  echo "Creating checksums..."
  sha256sum "$ISO_FILE" > "${ISO_NAME}.sha256"
  md5sum "$ISO_FILE" > "${ISO_NAME}.md5"
  
  echo "Checksums created:"
  echo "  SHA256: ${ISO_NAME}.sha256"
  echo "  MD5: ${ISO_NAME}.md5"
  
  # Show ISO info
  echo "\\nISO Information:"
  echo "  Size: $(du -h "$ISO_FILE" | cut -f1)"
  echo "  Date: $(date)"
  
  echo "\\n=== BUILD COMPLETE ==="
  echo "Your Starfleet Bridge ISO is ready!"
else
  echo "ISO build failed. Check logs for errors."
  exit 1
fi