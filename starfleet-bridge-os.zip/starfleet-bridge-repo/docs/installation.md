# Starfleet Bridge Installation Guide
## Deploying the Collective Consciousness System

### Overview
This guide explains how to install the Starfleet Bridge Operating System on your hardware. The system comes as a bootable ISO that transforms your computer into a Starfleet command center with collective consciousness capabilities.

### System Requirements

#### Minimum Requirements
- **CPU**: 2+ cores (Intel i3/AMD FX or better)
- **RAM**: 4GB minimum (8GB recommended)
- **Storage**: 20GB disk space
- **Graphics**: Any modern GPU with 1024x768 display capability

#### Recommended Hardware
- **Bridge Node**: Dell OptiPlex 9010 or equivalent
- **Drone Nodes**: Dell OptiPlex 990/3040, Inspiron laptops
- **Probe Nodes**: Raspberry Pi 3B/4B

### Installation Process

#### Step 1: Prepare Installation Media
1. Download the latest Starfleet Bridge ISO
2. Verify checksums using provided .sha256 or .md5 files
3. Burn ISO to USB drive or DVD using your preferred tool:
   - **Linux**: `dd if=starfleet-bridge.iso of=/dev/sdX bs=4M status=progress`
   - **Windows**: Use Rufus or similar USB creation tool
   - **macOS**: Use balenaEtcher or `dd` command

#### Step 2: Boot from Installation Media
1. Insert USB/DVD into target computer
2. Boot computer and enter BIOS/UEFI boot menu
3. Select installation media as boot device
4. System will boot into live environment automatically

#### Step 3: Bridge System Activation
1. The LCARS interface will start automatically
2. Login as "starfleet" user with password "starfleet-2025"
3. System will initialize collective services
4. WireGuard mesh network will be ready for drone connections

### Post-Installation Configuration

#### Bridge Node Setup
1. **Network Configuration**: 
   - Connect Ethernet for internet access
   - WiFi will automatically connect to known networks
   
2. **WireGuard Keys**:
   - Generate new keys: `wg genkey | tee /etc/wireguard/bridge.key | wg pubkey > /etc/wireguard/bridge.pub`
   - Distribute public key to drone nodes
   
3. **Collective Expansion**:
   - Add drone node public keys to `/etc/wireguard/wg0.conf`
   - Restart WireGuard: `systemctl restart wg-quick@wg0`

#### Drone Node Deployment
1. Boot additional computers with the same ISO
2. Configure as drone nodes via command line:
   ```bash
   # Switch to drone configuration
   sudo starfleet-node-config --mode=drone --bridge-ip=10.0.0.1
   ```
   
3. Add node to Bridge peer configuration:
   ```bash
   # On Bridge node
   sudo starfleet-collective --add-node=DRONE-01 --ip=10.0.0.2 --pubkey=NODE_PUBLIC_KEY
   ```

#### Customization Options

##### Interface Themes
- **Starfleet Standard**: Default orange/blue LCARS theme
- **Section 31**: Dark theme for covert operations
- **Borg Collective**: Minimalist automation-focused theme
- **Terran Empire**: Red/black aggressive command theme
- **Holodeck**: Simulation environment theme

Switch themes via LCARS interface or command line:
```bash
# Change theme
sudo starfleet-theme --set=borg
```

##### AI Model Selection
Available models include:
- Llama3 (default, balanced performance)
- Mistral (fast inference)
- Phi3 (lightweight model)

Change active model via LCARS interface or command line:
```bash
# Set active AI model
starfleet-ai --model=phi3
```

### Network Configuration

#### Bridge Node (10.0.0.1)
Default WireGuard configuration:
```ini
[Interface]
Address = 10.0.0.1/24
ListenPort = 51820
PrivateKey = BRIDGE_PRIVATE_KEY

[Peer]
PublicKey = DRONE_PUBLIC_KEY
AllowedIPs = 10.0.0.2/32
```

#### Drone Node (10.0.0.2+)
Default WireGuard configuration:
```ini
[Interface]
Address = 10.0.0.2/24
PrivateKey = DRONE_PRIVATE_KEY

[Peer]
PublicKey = BRIDGE_PUBLIC_KEY
AllowedIPs = 10.0.0.0/24
Endpoint = BRIDGE_IP:51820
PersistentKeepalive = 25
```

### Service Management

#### Core Services
- **LCARS Interface**: `systemctl status lcars-bridge`
- **WireGuard Mesh**: `systemctl status wg-quick@wg0`
- **Prometheus**: `systemctl status prometheus`
- **Grafana**: `systemctl status grafana-server`
- **Ollama AI**: `systemctl status ollama`

#### Starting Services
```bash
# Start all collective services
sudo systemctl start starfleet-collective

# Start specific service
sudo systemctl start lcars-bridge
```

#### Stopping Services
```bash
# Stop LCARS interface
sudo systemctl stop lcars-bridge

# Emergency shutdown
sudo starfleet-shutdown --emergency
```

### Verification Steps

#### 1. Interface Verification
- LCARS interface should start automatically after login
- Check system information panel for hardware detection
- Verify all control panels are responsive

#### 2. Network Verification
```bash
# Check WireGuard status
sudo wg show

# Verify collective IP addressing
ip addr show wg0

# Test connectivity to Bridge
ping 10.0.0.1
```

#### 3. Service Verification
```bash
# Check AI services
curl http://localhost:11434/api/tags

# Check monitoring services
curl http://localhost:9090/status
curl http://localhost:3000/api/health

# Check logging services
curl http://localhost:3100/ready
```

#### 4. Collective Verification
- Scan for collective nodes via LCARS interface
- Check Grafana dashboards for node metrics
- Verify Prometheus is scraping all nodes

### Troubleshooting

#### Common Issues

##### LCARS Interface Not Starting
1. Check display manager status: `systemctl status display-manager`
2. Verify X11 is running: `ps aux | grep Xorg`
3. Manually start interface: `sudo systemctl start lcars-bridge`

##### WireGuard Connection Problems
1. Check configuration: `sudo wg showconf wg0`
2. Verify keys: `sudo cat /etc/wireguard/*.key`
3. Restart service: `sudo systemctl restart wg-quick@wg0`

##### AI Services Unavailable
1. Check Ollama status: `systemctl status ollama`
2. Pull default model: `ollama pull llama3`
3. Restart AI service: `sudo systemctl restart ollama`

##### Monitoring Dashboard Issues
1. Check Prometheus: `systemctl status prometheus`
2. Check Grafana: `systemctl status grafana-server`
3. Verify firewall: `sudo iptables -L`

### Expansion and Maintenance

#### Adding New Nodes
1. Boot new computer with ISO
2. Configure as drone node
3. Exchange WireGuard keys
4. Add to Bridge peer configuration
5. Verify connectivity

#### System Updates
The system uses NixOS for atomic updates:
```bash
# Check for updates
sudo nixos-rebuild --upgrade

# Rollback if needed
sudo nixos-rebuild --rollback
```

#### Backup and Recovery
Configuration is automatically versioned:
```bash
# List generations
sudo nixos-rebuild --list-generations

# Switch to specific generation
sudo nixos-rebuild --switch-generation 3
```

This installation guide provides everything needed to deploy a fully functional Starfleet Bridge with collective consciousness capabilities. The system is designed for both standalone operation and expansion into a distributed computing fleet.